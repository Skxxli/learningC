#if !defined(MEMORY_CHECKING_H)
#define MEMORY_CHECKING_H

void setup_memory_checking(void);
void check_heap(void);

#endif
