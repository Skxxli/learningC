void setup_memory_checking(void);
void check_heap(void);
