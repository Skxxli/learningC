#if !defined(SPLIT_H)
#define SPLIT_H

/* (c) Larry Herman, 2016.  You are allowed to use this code yourself, but
 * not to provide it to anyone else.
 */

char **split(const char line[]);

#endif
