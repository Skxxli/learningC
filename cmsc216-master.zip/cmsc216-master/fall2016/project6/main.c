#include <stdio.h>
#include "functions.h"

/* (c) Larry Herman, 2016.  You are allowed to use this code yourself, but
 * not to provide it to anyone else.
 */

int main() {
  int a= 112, b= 104;

  printf("%d\n", add(a, b));

  return 0;
}
